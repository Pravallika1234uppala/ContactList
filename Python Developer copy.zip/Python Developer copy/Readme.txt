Back end: Python and Flask
This builds out an API

Also, connect that with Database.

Front end: React and Java Script

npm create vite@latest frontend -- --template react
This creates folder frontend 

Then run commands:
cd frontend
npm install

When building application want to build api or backend first.
(gives structure of application and different operations to perform)


Here, we create CRUD backend.

(Implement these 4 main operations)
create
Read
Update
Delete

In our case, it is one instance or one object.

1. creating contact
2. updating contact
3. deleting contact
4. fetching/getting contact


These involves setting routes that we can call. (routes are endpoints that we can call from anykind of application)
Can be any front end or backend also.

Idea: we define this protocol or application that defines set of operations that application has and them implement a front end.

In backend folder:

If pip not installed:
python -m pip install

we install few python directories:
pip3 install Flask
pip3 install Flask-SQLAlchemy       (--ORM-Object relational Mapping)
This allows us to connect to SQL database.
And map the entries in sequel into python object.
(to operate on object in easy way)

pip3 install flask-cors
This allows us to have cross origin requests.



In backend:
create files main.py, models.py, config.py

config.py - has main configuration of the application.
main.py - has main routes
models.py - has all database models
(This is how we interact with database)

We use Flask SQL Alchemy

Create a Python class(represents entry or row in database like table)
define diff col and data that this object storing.


http://127.0.0.1:5000-404
http://127.0.0.1:5000/contacts - get requests
returns empty list.


Shut server - Ctrl+C

Then can write other routes for creating, updating etc..

So, what we can do is test API before working on frontend.
(backend - all data related stuff working then can move to frontend)

Tools to do this:
1. Postman
Allows you to send most specific requests like post requests.
(with json data to an API especially in a development environment.)


After finishing backend we finished API

Frontend:
now in frontend will see how to interact with the backend.

in frontend go to src and delete few things.
access- can delete folder
in app.jsx - can remove 
import viteLogo
import reactLogo assests
(delete everything inside it.) except fragment


go to public 
delete Logo

In index.html:
can remove logo reference and change title.(Contact List)

This is all.

Now, we need to fetch contacts:
Display contacts:
form for creating contacts:
Updating and deleting contacts:


In App.jsx:

set up a state which stores contacts.


To run backend:
cd backend
python3 main.py

To run frontend:
split server
cd frontend
npm run dev
(frondend server)
runs on diff port

Everytime we refresh new get request happening in backend server.
can see array of 0 elements
fetching contacts but no contacts.


Display all the diff contacts:
create a form that allows us to create a new contact.

create a new file named ContactList.jsx in src.
used contacts from App.jsx 
so, need to export from that to ContactList.jsx

e.preventDefault() - to not refreshing the page automatically.

setting up modal:
app.jsx-
set to true when you want to open the modal.
Modal can be opened in 2 ways:
1. creating contact
2. editing a contact
